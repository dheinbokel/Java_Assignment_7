
import java.util.Date;
import java.util.Scanner;

public class ATM {

    private static final int MAX_ATTEMPTS = 3;

    /**
     * The main method of the program.
     * @param args
     */
    public static void main(String[] args){

        Scanner scan = new Scanner(System.in);
        Bank bank = new Bank("Doug's Bank");

        boolean keepGoing = true;
        CardHolder atmUser;
        int attempts = 0;

        while(keepGoing == true){

            atmUser = ATM.menuPrompt(bank, scan);
            if(atmUser == null){
                attempts++;
                System.out.println("Sorry, either the id or the pin is invalid.");
                if(attempts == MAX_ATTEMPTS){
                    System.out.println("Sorry, your card will now be locked.  Please come to the bank to retrieve your card.");
                    keepGoing = false;
                }
            }
            else{

                ATM.userMenu(atmUser, scan);
                keepGoing = false;
            }
        }
        System.out.println("NEXT!");
    }

    /**
     * This is what the user interacts with to perform transactions.  A type of transaction is
     * picked and then the related function call is performed.
     * @param user
     * @param scan
     */
    public static void userMenu(CardHolder user, Scanner scan){

        user.displayAccounts();

        int choice;
        boolean valid = true;
        boolean keepGoing = true;

        while(keepGoing == true) {
            do {
                System.out.println("Please choose an option:");
                System.out.println("1: Withdraw");
                System.out.println("2: Deposit");
                System.out.println("3: Transfer");
                System.out.println("4: Account Transactions");
                System.out.println("5: Cancel");

                choice = scan.nextInt();
                if (choice < 1 || choice > 5) {

                    System.out.println("Sorry, that input is invalid.");
                    valid = false;
                } else {
                    valid = true;
                }

            } while (valid == false);

            switch (choice) {

                case 1:
                    ATM.withdrawAmount(user, scan);
                    break;
                case 2:
                    ATM.depositAmount(user, scan);
                    break;
                case 3:
                    ATM.transferAmount(user, scan);
                    break;
                case 4:
                    ATM.showTransactions(user, scan);
                    break;
                case 5:
                    keepGoing = false;
                    System.out.println("Goodbye.");
                    break;
                default:
                    System.out.println("Sorry, that input is not an option.");
                    break;
            }
        }
    }

    /**
     * Displays the transactions for a chosen account
     * @param user
     * @param scan
     */
    public static void showTransactions(CardHolder user, Scanner scan){

        int account;
        boolean valid;

        do {
            System.out.println("Which account would you like to view? 0 to quit.");
            System.out.println();
            user.displayAccounts();

            account = scan.nextInt() - 1;
            if(account >= user.amountOfAccounts()){
                System.out.println("Invalid account, please use the numbers by the account names.");
                valid = false;
            }
            else{
                valid = true;
            }

        }while(valid == false);

        if(account >= 0){

            user.showTransactions(account);
        }
        else{
            System.out.println("Goodbye.");
        }
    }

    /**
     * Lets the user deposit a certain amount to their chosen account.  A teller in the bank
     * will have to make sure this amount is correct on the check.
     * @param user
     * @param scan
     */
    public static void depositAmount(CardHolder user, Scanner scan){

        Date time = new Date();
        int account;
        double amount;
        boolean valid = true;

        do {
            System.out.println("Which account would you like to deposit into? 0 to quit.");
            System.out.println();
            user.displayAccounts();

            account = scan.nextInt() - 1;
            if(account >= user.amountOfAccounts()){
                System.out.println("Invalid account, please use the numbers by the account names.");
                valid = false;
            }
            else if(account < 0){
                System.out.println("Goodbye.");
                valid = true;
            }
            else{
                valid = true;
            }

        }while(valid == false);

        if(account >= 0) {
            do {

                System.out.println("How much to deposit? Must be more than 0, press 0 to quit.");
                System.out.println();

                amount = scan.nextDouble();

                if (amount < 0) {

                    System.out.println("Sorry, must be more than 0.");
                    valid = false;

                }else {

                    valid = true;
                }

            } while (valid == false);

            if(amount != 0) {
                user.addTransaction(account, amount, "Deposited $" + amount + "to account " + user.getAccountID(account));
                user.changeAccountBalance(account, amount);

                System.out.println("Deposited $" + amount + "to account " + user.getAccountID(account));
                System.out.println("On " + time);

                user.displayAccounts();
            }
            else{
                System.out.println("Goodbye.");
            }
        }
    }

    /**
     * Withdraws money from a chosen account and changes the value in the account balance
     * @param user
     * @param scan
     */
    public static void withdrawAmount(CardHolder user, Scanner scan){

        Date time = new Date();
        int account;
        double validAmount;
        double amount;
        boolean valid = true;

        do {
            System.out.println("Which account would you like to withdraw from? 0 to quit.");
            System.out.println();
            user.displayAccounts();

            account = scan.nextInt() - 1;
            if(account >= user.amountOfAccounts()){
                System.out.println("Invalid account, please use the numbers by the account names.");
                valid = false;
            }
            else{
                valid = true;
            }

        }while(valid == false);

        if(account >= 0) {
            validAmount = user.getAccountBalance(account);

            do {

                System.out.println("How much to withdraw? Must be in multiples of $20");
                System.out.println("Maximum available: " + validAmount);
                System.out.println();

                amount = scan.nextDouble();

                if (amount > validAmount || amount < 0) {

                    System.out.println("Sorry, amount can't be less than 0 or more than what is in the account.");
                    valid = false;
                } else if (amount % 20 != 0) {

                    System.out.println("Sorry, amount must be in multiples of $20.");
                    valid = false;
                } else if (amount == 0) {

                    System.out.println("Goodbye.");
                    valid = true;
                } else {

                    valid = true;
                }

            } while (valid == false);

            if(amount != 0) {
                user.addTransaction(account, amount, "Withdrew $" + amount +  "from account " + user.getAccountID(account));
                user.changeAccountBalance(account, -1 * amount);

                System.out.println("Withdrew $" + amount + " from account " + user.getAccountID(account));
                System.out.println("On " + time);
                user.displayAccounts();
            }
        }
        else{

            System.out.println("Goodbye.");
        }
    }

    /**
     * Takes user input to determine which account to transfer from and to.  After correct
     * inputs have been made, 2 transactions, 1 for each account used, are made and the amounts
     * in the accounts are changed.
     * @param user
     * @param scan
     */
    public static void transferAmount(CardHolder user, Scanner scan){

        Date time = new Date();;
        int fromAcc;
        int toAcc;
        double validAmount;
        double amount;
        boolean valid = true;

        do {
            System.out.println("Which account would you like to transfer from? 0 to quit.");
            System.out.println();
            user.displayAccounts();

            fromAcc = scan.nextInt() - 1;
            if(fromAcc >= user.amountOfAccounts()){
                System.out.println("Invalid account, use the numbers by the account names.");
                valid = false;
            }
            else{

                valid = true;
            }

        }while(valid == false);

        if(fromAcc >= 0) {
            validAmount = user.getAccountBalance(fromAcc);

            do {
                System.out.println("Which account would you like to transfer to? 0 to quit.");
                System.out.println();
                user.displayAccounts();

                toAcc = scan.nextInt() - 1;
                if (toAcc >= user.amountOfAccounts()) {
                    System.out.println("Invalid account, please use the numbers by the account names.");
                    valid = false;
                }
                else {

                    valid = true;
                }

            } while (valid == false);

            if(toAcc >= 0) {
                do {

                    System.out.println("How much would you like to transfer? 0 to quit.");
                    System.out.println("Maximum available: " + validAmount);
                    System.out.println();

                    amount = scan.nextDouble();

                    if (amount > validAmount || amount < 0) {

                        System.out.println("Sorry, amount can't be higher than the balance and must be more than 0.");
                        valid = false;
                    } else if (amount == 0) {
                        System.out.println("Goodbye.");
                        valid = true;
                    } else {
                        valid = true;
                    }
                } while (valid == false);

                if(amount != 0) {
                    //Add transaction for the "from" account and then change the balance in that account.
                    user.addTransaction(fromAcc, amount, "Transferred $" + amount + " from account " + user.getAccountID(fromAcc));
                    user.changeAccountBalance(fromAcc, -1 * amount);

                    //Add transaction for the "to" account and then change the balance in that account.
                    user.addTransaction(toAcc, amount, "Transferred $" + amount + " to account " + user.getAccountID(toAcc));
                    user.changeAccountBalance(toAcc, amount);

                    //Lets the customer know transaction succeeded.  This would be printed to the screen after each transaction.
                    System.out.println("Transferred $" + amount + " from account " + user.getAccountID(fromAcc));
                    System.out.println("Transferred $" + amount + " to account " + user.getAccountID(toAcc));
                    System.out.println("On " + time);

                    //Shows user accounts
                    user.displayAccounts();
                }
            }
            else{
                System.out.println("Goodbye.");
            }
        }
        else{
            System.out.println("Goodbye.");
        }

    }

    /**
     * Asks the user for their id and pin.  The information is then sent to the bank to check whether there is a user with this id
     * and if the pin entered matches that account id.
     * @param bank
     * @param scan
     * @return user
     */
    public static CardHolder menuPrompt(Bank bank, Scanner scan){

        String cardID;
        String cardPin;
        CardHolder user;

        //Since the users get created each time the program starts instead of getting taken in by a database or file, the
        //ids of the CardHolders are random uniques.  So for this project the information is displayed so you can see the ids to input.
        System.out.println("Enter card ID: ");
        cardID = scan.nextLine();
        System.out.println("Enter pin: ");
        cardPin = scan.nextLine();

        user = bank.checkCard(cardID, cardPin);

        return user;
    }

}
