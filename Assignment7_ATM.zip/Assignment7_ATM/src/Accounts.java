import java.util.ArrayList;

public class Accounts {

    private String name;
    private String id;
    private double balance;
    private CardHolder user;
    private ArrayList<Transactions> transaction;

    /**
     * Constructor for the Accounts class
     * @param name
     * @param bank
     * @param person
     * @param balance
     */
    public Accounts(String name, Bank bank, CardHolder person, double balance){

        this.name = name;
        this.user = person;
        this.balance = balance;
        this.id = bank.getNewAccountID();

        this.transaction = new ArrayList<Transactions>();

    }

    /**
     * Prints out a list of transactions in the account
     */
    public void displayTransactions(){

        if(transaction.size() > 0) {
            for (int i = transaction.size() - 1; i >= 0; i--) {

                transaction.get(i).displayTransactions();
            }

       /* for(Transactions transAct : transaction){

            transAct.displayTransactions();
        }*/
        }
        else{
            System.out.println("Sorry, there are no transactions yet.");
        }
    }

    /**
     * Modifies the balance in the account
     * @param amount
     */
    public void changeBalance(double amount){

        balance += amount;
    }

    /**
     * Adds a transaction to the transaction ArrayList
     * @param amount
     * @param details
     */
    public void addTransaction(double amount, String details){

        Transactions newTran = new Transactions(amount, this, details);
        transaction.add(newTran);
    }

    /**
     * Returns the balance of the account
     * @return balance
     */
    public double getBalance(){

        return balance;
    }

    /**
     * Returns the balance of the account
     * @return balance
     */
    public String getName(){

        return name;
    }

    /**
     * Returns id
     * @return
     */
    public String getAccID(){

        return id;
    }
}
