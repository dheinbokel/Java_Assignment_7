import java.util.ArrayList;

public class CardHolder {

    private String firstName;
    private String lastName;
    private String id;
    private String pin;
    private ArrayList<Accounts> account;

    /**
     * Constructor for the CardHolder class.
     * @param firstName
     * @param lastName
     * @param pin
     * @param bank
     *
     */
    public CardHolder(String firstName, String lastName, String pin, Bank bank){

        //Initializing fields to passed-in parameters
        this.firstName = firstName;
        this.lastName = lastName;
        this.pin = pin;
        this.id = bank.getNewID();
        this.account = new ArrayList<Accounts>();

        System.out.println("User: " + this.firstName + " " + this.lastName + " Pin: " + this.pin + " ID: " + this.id);

    }

    /**
     * Passes an account the amount to change the account balance by
     * @param index
     * @param amount
     */
    public void changeAccountBalance(int index, double amount){

        account.get(index).changeBalance(amount);
    }

    /**
     * Return the account ID of the account at a certain index
     * @param index
     * @return
     */
    public String getAccountID(int index){

        return account.get(index).getAccID();
    }

    /**
     * Adds a transaction to the account
     * @param index
     * @param amount
     * @param details
     */
    public void addTransaction(int index, double amount, String details){

        account.get(index).addTransaction(amount, details);
    }

    /**
     * Displays the name of the user's accounts as well as the balance they hold.
     */
    public void displayAccounts(){

        int i = 1;
        for(Accounts accounts : account){
            System.out.println(i + ") " + "Account: " + accounts.getName() + ", Balance: " + accounts.getBalance());
            i++;
        }
    }

    /**
     * Prints out a list of transactions for the given account
     * @param index
     */
    public void showTransactions(int index){

        account.get(index).displayTransactions();
    }

    /**
     * Returns the balance stored in the account at the given index
     * @param index
     * @return
     */
    public double getAccountBalance(int index){

        return account.get(index).getBalance();
    }

    /**
     * Returns an account at the index in the parameter
     * @param index
     * @return
     */
    public Accounts getAccount(int index){

        return account.get(index);
    }

    /**
     * Returns the size of the array list account
     * @return the size of the array list
     */
    public int amountOfAccounts(){

        return account.size();
    }

    /**
     * Adds an account to the accounts ArrayList
     * @param account
     */
    public void addAccount(Accounts account){

        this.account.add(account);
    }

    /**
     * Returns pin
     * @return pin
     */
    public String getPin(){

        return pin;
    }

    /**
     * Returns the value stored in id
     */
    public String getID(){

        return id;
    }

    /**
     * Returns the first name of the user
     * @return firstName
     */
    public String getFirstName(){

        return firstName;
    }

    /**
     * Returns the last name of the user
     * @return lastName
     */
    public String getLastName(){

        return lastName;
    }
}
