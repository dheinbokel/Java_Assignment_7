import java.util.ArrayList;
import java.util.Random;

public class Bank {

    private String bankName;
    private ArrayList<CardHolder> users;
    private ArrayList<Accounts> accounts;

    /**
     * Constructor for the Bank class.  Creates a list of card holders that already have accounts at the bank.
     * @param name
     */
    public Bank(String name){

        bankName = name;
        users = new ArrayList<CardHolder>();
        accounts = new ArrayList<Accounts>();

        this.addNewHolder("Doug", "Heinbokel", "1213");
        this.addNewHolder("Bob", "Heinbokel", "1111");
        this.addNewHolder("Sean", "Neill", "9865");
        this.addNewHolder("Mike", "Reck", "4091");
        this.addNewHolder("Tyler", "Burrows", "7743");
    }

    /**
     * Creates a unique id for the CardHolder id.  After creating a random id, checks whether the id is already used.
     * @return id
     */
    public String getNewID(){

        String id;
        Random newRand = new Random();
        int idLen = 8;
        boolean notUnique = false;

        do{
            notUnique = false;
            id = "";

            for(int i = 0; i < idLen; i++) {
                id += ((Integer) newRand.nextInt(10)).toString();
            }

            for(CardHolder user : users){
                if(id.equals(user.getID())){
                    notUnique = true;
                    break;
                }
            }

        } while(notUnique);

        return id;
    }

    /**
     * Creates a new random account id for an account.  If id already exists, loop is rerun to get a different one.
     * @return
     */
    public String getNewAccountID(){

        String id;
        Random newRand = new Random();
        int idLen = 9;
        boolean notUnique = false;

        do{
            notUnique = false;
            id = "";

            for(int i = 0; i < idLen; i++) {
                id += ((Integer) newRand.nextInt(10)).toString();
            }

            for(Accounts account : accounts){
                if(id.equals(account.getAccID())){
                    notUnique = true;
                    break;
                }
            }

        } while(notUnique);

        return id;
    }

    /**
     * Checks to see if the CardHolder's info is correct
     * @param cardId
     * @param pin
     * @return
     */
    public CardHolder checkCard(String cardId, String pin){

        for(CardHolder user : users){

            if(user.getID().equals(cardId) && user.getPin().equals(pin)){

                return user;
            }
        }
        return null;
    }

    /**
     * Adds an account to the accounts ArrayList
     * @param account
     */
    public void addAccount(Accounts account){

        this.accounts.add(account);
    }

    /**
     * Add a new CardHolder to the users ArrayList.  This also gives the users their default accounts that would appear in a real
     * bank account set up.  4
     * @param fName
     * @param lName
     * @param userPin
     * @return
     */
    public CardHolder addNewHolder(String fName, String lName, String userPin){

        CardHolder newHolder = new CardHolder(fName, lName, userPin, this);
        this.users.add(newHolder);

        //Create the accounts for the new CardHolder since we have no database to draw accounts and users from.
        //Default amounts have been added in the accounts to give the users something to interact with.

        Accounts newAccount = new Accounts("Checking", this, newHolder, 1000.00);
        Accounts saveAccount = new Accounts("Savings", this, newHolder, 200.00);
        newHolder.addAccount(newAccount);
        newHolder.addAccount(saveAccount);
        this.addAccount(newAccount);
        this.addAccount(saveAccount);

        return newHolder;
    }

    public String getBankName(){

        return bankName;
    }
}
