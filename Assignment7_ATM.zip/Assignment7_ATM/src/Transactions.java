import java.util.Date;

public class Transactions {

    private Date time;
    private String details;
    private Accounts account;
    private double amount;

    /**
     * Constructor for the Transactions class.
     * @param amount
     * @param account
     * @param details
     */
    public Transactions(double amount, Accounts account, String details){

        this.amount = amount;
        this.details = details;
        this.account = account;
        time = new Date();
    }

    /**
     * Displays the transaction details
     */
    public void displayTransactions(){

        System.out.println(details + " at " + time);
    }
}

